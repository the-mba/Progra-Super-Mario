from Game import Game

Game()